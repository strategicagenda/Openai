<?php
/**
 * The template for displaying single Grantee posts.
 *
 * To override this template in a child theme, copy this file to your
 * child theme's folder: your-theme/grantee-listing/single-grantee.php
 */

get_header(); // Loads your theme's header.php file
?>

<div id="primary" class="content-area grantee-single-page">
    <main id="main" class="site-main grantee-single-main" role="main">

        <?php
        // Start the WordPress Loop to get the single grantee post data.
        while ( have_posts() ) :
            the_post(); // Sets up the current post object

            $post_id = get_the_ID(); // Get the ID of the current post

            // --- Retrieve Custom Field Data ---
            $logo_id        = get_post_meta( $post_id, '_grantee_logo_id', true );
            $logo_url       = '';
            if ($logo_id) {
                $logo_url = wp_get_attachment_image_url( $logo_id, 'medium' ); // Use medium size
            } elseif (has_post_thumbnail($post_id)) {
                $logo_url = get_the_post_thumbnail_url($post_id, 'medium');
            }

            $project_name   = get_post_meta( $post_id, '_grantee_project_name', true );
            $start_date_raw = get_post_meta( $post_id, '_grantee_start_date', true );
            $end_date_raw   = get_post_meta( $post_id, '_grantee_end_date', true );
            $address        = get_post_meta( $post_id, '_grantee_address', true );
            $website        = get_post_meta( $post_id, '_grantee_website', true );
            $socials_raw    = get_post_meta( $post_id, '_grantee_socials', true ); // Stored as one link per line
            $funding_amount_raw = get_post_meta( $post_id, '_grantee_funding_amount', true );

            // --- Format Data for Display ---
            $currency_symbol = '$'; // Default currency symbol - you can change this here or make it a plugin option later
            $funding_amount_formatted = '';
            if (!empty($funding_amount_raw) && is_numeric($funding_amount_raw)) {
                // Format the number with thousands separators and currency symbol
                $funding_amount_formatted = esc_html($currency_symbol) . number_format_i18n(floatval($funding_amount_raw), 0); // 0 decimals for whole numbers like example
            }

            // Format timeline for display
            $timeline_display = '';
            if ($start_date_raw) {
                 $timeline_display .= date_i18n('F Y', strtotime($start_date_raw)); // E.g., "October 2017"
            }
            if ($end_date_raw) {
                $timeline_display .= ($timeline_display ? ' &ndash; ' : '') . date_i18n('F Y', strtotime($end_date_raw)); // E.g., "October 2019"
            }

            // Get Countries Involved terms
            $countries = get_the_terms( $post_id, 'grantee_country' );
            $countries_list = '';
            if ( $countries && ! is_wp_error( $countries ) ) {
                $country_names = array();
                foreach ( $countries as $country_term ) {
                    $country_names[] = esc_html( $country_term->name );
                }
                $countries_list = join( ', ', $country_names );
            }

            // Get Grantee Types terms (not shown in the specific example, but kept in sidebar meta)
            $grantee_types = get_the_terms( $post_id, 'grantee_type' );
            $types_list_sidebar = '';
             if ( $grantee_types && ! is_wp_error( $grantee_types ) ) {
                $type_links = array();
                foreach ( $grantee_types as $type_term ) {
                    // Link to archive page for each type
                    $type_links[] = '<a href="' . esc_url( get_term_link( $type_term ) ) . '">' . esc_html( $type_term->name ) . '</a>';
                }
                $types_list_sidebar = join( ', ', $type_links );
            }

            // Process Social Media Links (assuming one URL per line in the admin field)
            $social_links = [];
            if (!empty($socials_raw)) {
                $lines = explode("\n", $socials_raw); // Split by line breaks
                foreach ($lines as $line) {
                    $line = trim($line); // Remove leading/trailing whitespace
                    if (filter_var($line, FILTER_VALIDATE_URL)) { // Check if it's a valid URL
                        // Basic domain extraction for link text (e.g., twitter.com) - can be improved for specific social icons
                        $domain = str_ireplace('www.', '', parse_url($line, PHP_URL_HOST));
                         // Add to array as list item HTML
                        $social_links[] = '<li><a href="' . esc_url($line) . '" target="_blank" rel="noopener noreferrer">' . esc_html(ucfirst($domain)) . '</a></li>';
                    }
                }
            }
            ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class('grantee-single-entry'); // Add CSS classes ?>>
                <div class="grantee-single-content-wrap">

                    <div class="grantee-main-narrative">
                        <header class="entry-header">
                            <?php
                            // Display Grantee Name (Post Title)
                            the_title( '<h1 class="entry-title grantee-name">', '</h1>' );
                            ?>
                            <?php if ( $project_name ) : // Display Project Name if entered ?>
                                <h2 class="grantee-project-name"><?php echo esc_html( $project_name ); ?></h2>
                            <?php endif; ?>
                        </header><!-- .entry-header -->

                        <?php if ( $countries_list ) : // Display Countries Involved if entered ?>
                            <div class="grantee-info-block grantee-countries-involved">
                                <strong><?php _e( 'Countries involved:', 'grantee-listing' ); ?></strong>
                                <p><?php echo $countries_list; // Already escaped ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if ( $timeline_display ) : // Display Grant Timeline if dates entered ?>
                             <div class="grantee-info-block grantee-project-timeline-main">
                                <!-- No strong label in example for this, just the dates -->
                                <p><?php echo $timeline_display; // Already escaped ?></p>
                            </div>
                        <?php endif; ?>


                        <div class="entry-content grantee-description">
                            <?php
                            // Display the main description (the content from the editor)
                            the_content();

                            // Handle multi-page posts if needed (rare for this CPT)
                            wp_link_pages(
                                array(
                                    'before'   => '<nav class="page-links" aria-label="' . esc_attr__( 'Page', 'grantee-listing' ) . '">',
                                    'after'    => '</nav>',
                                    /* translators: %: Page number. */
                                    'pagelink' => esc_html__( 'Page %', 'grantee-listing' ),
                                )
                            );
                            ?>
                        </div><!-- .entry-content -->
                    </div><!-- .grantee-main-narrative -->

                    <aside class="grantee-sidebar-meta">
                         <div class="grantee-key-meta-block">
                            <?php if ( $logo_url ) : // Display Logo in the sidebar if uploaded/set ?>
                                <div class="grantee-sidebar-logo">
                                    <img src="<?php echo esc_url( $logo_url ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?> Logo">
                                </div>
                            <?php endif; ?>

                            <?php if ( $funding_amount_formatted ) : // Display Funding Amount ?>
                                <div class="grantee-sidebar-block">
                                    <strong><?php _e( 'Funding amount:', 'grantee-listing' ); ?></strong>
                                    <p><?php echo $funding_amount_formatted; // Already escaped ?></p>
                                </div>
                            <?php endif; ?>

                            <?php if ( $address ) : // Display Address ?>
                                <div class="grantee-sidebar-block">
                                    <strong><?php _e( 'Address:', 'grantee-listing' ); ?></strong>
                                    <p><?php echo nl2br(esc_html( $address )); ?></p>
                                </div>
                            <?php endif; ?>
                         </div><!-- .grantee-key-meta-block -->


                        <?php // Additional Meta Fields (not strictly shown in example, but useful) ?>
                         <?php if ( $types_list_sidebar ) : // Display Grantee Types ?>
                            <div class="grantee-sidebar-block grantee-types-sidebar">
                                <strong><?php _e( 'Grantee Type(s):', 'grantee-listing' ); ?></strong>
                                <p><?php echo $types_list_sidebar; ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if ( $website ) : // Display Website ?>
                            <div class="grantee-sidebar-block grantee-website-sidebar">
                                <strong><?php _e( 'Grantee website:', 'grantee-listing' ); ?></strong>
                                <p><a href="<?php echo esc_url( $website ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( preg_replace( '#^https?://(www\.)?#i', '', $website ) ); ?></a></p>
                            </div>
                        <?php endif; ?>

                        <?php if ( !empty($social_links) ) : // Display Social Links ?>
                            <div class="grantee-sidebar-block grantee-socials-sidebar">
                                <strong><?php _e( 'Socials:', 'grantee-listing' ); ?></strong>
                                <ul>
                                    <?php echo implode('', $social_links); ?>
                                </ul>
                            </div>
                        <?php endif; ?>


                    </aside><!-- .grantee-sidebar-meta -->
                </div><!-- .grantee-single-content-wrap -->
            </article><!-- #post-## -->

            <?php
            // Include comments template if comments are enabled
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }

        endwhile; // End of the loop.
        ?>

    </main><!-- .site-main -->
</div><!-- .content-area -->

<?php get_footer(); // Loads your theme's footer.php file ?>